# Digital Barath Full Stack Project
Frontend: HTML/CSS/JS
Backend: Node.js + Express
Database: MongoDB